library(shiny)
library(shinydashboard) 
library(cbsodataR) 
library(data.table)
library(tidyverse) 
library(plotly) 
library(scales) 
library(leaflet)
library(leaflet.extras) 
library(leaflet.minicharts) 
library(geojsonio)
library(geojsonR) 
library(RColorBrewer) 
library(magrittr)
library(tigris) 
library(htmlwidgets) 
library(patchwork)
library(ggiraph)
library(sf)

#region codes = "LD01  "(Nothern Netherlands), "PV20  "(Groningen), "PV21  "(Fryslan), "PV22  "(Drenthe)
#color codes = "#FF0000" (red), "#52E74B" (green), "#6854D8"(purple), "#FFC0CB"(pink), "#0000FF"(blue), "#FFA500"(orange)

#gets meta data of dataset

regionalkeyfigures_meta <- cbs_get_meta("70072NED")

#gets dataset

regionalkeyfigures <- cbs_get_data(id = "70072NED", 
                                   RegioS = c("LD01  ", "PV20  ", "PV21  ", "PV22  "),
                                   select = c("RegioS", "Perioden",  "TotaleBevolking_1", "Mannen_2", "Vrouwen_3", "VoortgezetOnderwijs_108", "MiddelbaarBeroepsonderwijs_109", "HogerBeroepsonderwijsBachelor_110", "WoMasterDoctoraal_111", "BedrijfsvestigingenTotaal_164", "ALandbouwBosbouwEnVisserij_165", "BFNijverheidEnEnergie_166", "GIHandelEnHoreca_167", "HJVervoerInformatieEnCommunicatie_168", "KLFinancieleDienstenOnroerendGoed_169", "MNZakelijkeDienstverlening_170", "RUCultuurRecreatieOverigeDiensten_171"),
                                   typed = TRUE)

#converts annoying yyyyXXmm format to numeric and removes unwanted columns

regionalkeyfigures <- cbs_add_date_column(regionalkeyfigures, date_type = "numeric") %>%
  select(-c(2, 4))

regionalkeyfigures <- regionalkeyfigures%>%
  mutate(RegioS = case_when(
    RegioS == "LD01  " ~ "NothernNL",
    RegioS == "PV20  " ~ "Groningen",
    RegioS == "PV21  " ~ "Fryslân",
    RegioS == "PV22  " ~ "Drenthe"))

#"NothernNL" == "LD01  ","Groningen" == "PV20  ","Fryslân" == "PV21  ","Drenthe" == "PV22  ")

#filtering table to single Region
NothernNLkeyfigures <- regionalkeyfigures %>%
  filter(RegioS == "NothernNL")%>%
  select(RegioS, Perioden_numeric, TotaleBevolking_1, Mannen_2, Vrouwen_3)%>%
  rename(Region = RegioS,
         Period = Perioden_numeric,
         Total_Population = TotaleBevolking_1,
         Men = Mannen_2,
         Women = Vrouwen_3)

Groningenkeyfigures <- regionalkeyfigures %>%
  filter(RegioS == "Groningen")%>%
  select(RegioS, Perioden_numeric, TotaleBevolking_1, Mannen_2, Vrouwen_3)%>%
  rename(Region = RegioS,
         Period = Perioden_numeric,
         Total_Population = TotaleBevolking_1,
         Men = Mannen_2,
         Women = Vrouwen_3)

Fryslankeyfigures <- regionalkeyfigures %>%
  filter(RegioS == "Fryslân")%>%
  select(RegioS, Perioden_numeric, TotaleBevolking_1, Mannen_2, Vrouwen_3)%>%
  rename(Region = RegioS,
         Period = Perioden_numeric,
         Total_Population = TotaleBevolking_1,
         Men = Mannen_2,
         Women = Vrouwen_3)

Drenthekeyfigures <- regionalkeyfigures %>%
  filter(RegioS == "Drenthe")%>%
  select(RegioS, Perioden_numeric, TotaleBevolking_1, Mannen_2, Vrouwen_3)%>%
  rename(Region = RegioS,
         Period = Perioden_numeric,
         Total_Population = TotaleBevolking_1,
         Men = Mannen_2,
         Women = Vrouwen_3)

#to get the demographics data
demographics <- read_csv("demographics.csv", 
                         col_types = cols(Perioden = col_character(), Totalen = col_integer()))

demographics <- demographics %>% 
  rename(
    Total = Totalen,
    Period = Perioden
  )

#Age data manipulation
Age <- demographics %>% filter(Subject == "age") %>% 
  filter(Region == "Groningen (PV)" | Region == "Drenthe (PV)" | Region == "Fryslân (PV)") 


Age$Region <- recode(Age$Region,
                     "Groningen (PV)" = "Groningen",
                     "Drenthe (PV)" = "Drenthe",
                     "Fryslân (PV)" =  "Fryslân")

Age <-
  Age %>% 
  mutate(percentageX = (Age$Total/ Age$Total[Subsubject == "Total"])*100) 

Age <- Age %>% 
  filter(Subsubject != "Total") 

Age <- Age  %>% mutate(Subsubject = fct_relevel(Subsubject, "0 to 5 years",  
                                                "5 tot 10 jaar",  "10 tot 15 jaar",  "15 tot 20 jaar", "20 tot 25 jaar",   
                                                "25 tot 30 jaar", "30 tot 35 jaar","35 tot 40 jaar","40 tot 45 jaar", 
                                                "45 tot 50 jaar", "50 tot 55 jaar", "55 tot 60 jaar", "60 tot 65 jaar", 
                                                "65 tot 70 jaar","70 tot 75 jaar","75 tot 80 jaar", "80 tot 85 jaar",
                                                "85 tot 90 jaar", "90 tot 95 jaar", "95 jaar of ouder"))


#education data manipulation
edulevels <- regionalkeyfigures %>%
  filter(Perioden_numeric > 2004, Perioden_numeric < 2020)%>%
  select(RegioS, Perioden_numeric, VoortgezetOnderwijs_108, MiddelbaarBeroepsonderwijs_109, HogerBeroepsonderwijsBachelor_110, WoMasterDoctoraal_111)%>%
  rename(Region = RegioS,
         Period = Perioden_numeric,
         VO = VoortgezetOnderwijs_108,
         MBO = MiddelbaarBeroepsonderwijs_109, 
         HBO = HogerBeroepsonderwijsBachelor_110, 
         WO = WoMasterDoctoraal_111)


NorthernNLedulevels <- edulevels %>%
  filter(Region == "NothernNL")

Groningenedulevels <- edulevels %>%
  filter(Region == "Groningen")

Fryslanedulevels <- edulevels %>%
  filter(Region == "Fryslân")


Drentheedulevels <- edulevels %>%
  filter(Region == "Drenthe")

#Mortality data manipulation
Mortality <- demographics %>% 
  filter(Subject == "Overledenen") %>% 
  filter(Region == "Groningen (PV)" | Region == "Drenthe (PV)" | Region == "Fryslân (PV)")

Mortality$Region <- recode (Mortality$Region,
                            "Groningen (PV)" = "Groningen",
                            "Drenthe (PV)" = "Drenthe",
                            "Fryslân (PV)" =  "Fryslân")

newKeyfigure <- rbind(Drenthekeyfigures, Groningenkeyfigures, Fryslankeyfigures)

newKeyfigure <- newKeyfigure %>% 
  filter(Period %in% ("2002":"2020"))

Mortality <- Mortality[order(Mortality$Region),]

Mortality <- Mortality %>% mutate(percentageY = (Mortality$Total / newKeyfigure$Total_Population) *100)

#Birth rate data manipulation
Births <- demographics %>% filter(Subject == "Levend geboren kinderen") %>% 
  filter(Region == "Groningen (PV)" | Region == "Drenthe (PV)" | Region == "Fryslân (PV)")

Births$Region <- recode (Births$Region,
                         "Groningen (PV)" = "Groningen",
                         "Drenthe (PV)" = "Drenthe",
                         "Fryslân (PV)" =  "Fryslân")

Births <- Births[order(Births$Region),]

Births <- Births %>% mutate(percentageZ = (Births$Total / newKeyfigure$Total_Population) *100)

#Businesses Data Manipulation
NothernNLBusinesses <- regionalkeyfigures %>%
  select(RegioS, Perioden_numeric, BedrijfsvestigingenTotaal_164, ALandbouwBosbouwEnVisserij_165, BFNijverheidEnEnergie_166, GIHandelEnHoreca_167, HJVervoerInformatieEnCommunicatie_168, KLFinancieleDienstenOnroerendGoed_169, MNZakelijkeDienstverlening_170, RUCultuurRecreatieOverigeDiensten_171)%>%
  filter(Perioden_numeric < 2021, Perioden_numeric > 2012)%>%
  filter(RegioS == "NothernNL")

NothernNLBusinesses <- NothernNLBusinesses %>%
  mutate(
    "A - Agriculture, Forest Management and Fishing" = round((NothernNLBusinesses$ALandbouwBosbouwEnVisserij_165 / NothernNLBusinesses$BedrijfsvestigingenTotaal_164), digits = 2), 
    "BF - Industry and Energy" = round((NothernNLBusinesses$BFNijverheidEnEnergie_166 / NothernNLBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "GI - Commerce and Hospitality" = round((NothernNLBusinesses$GIHandelEnHoreca_167 / NothernNLBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "HJ - Information and Communication" = round((NothernNLBusinesses$HJVervoerInformatieEnCommunicatie_168 / NothernNLBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "KL - Financial Services Regarding Real Estate " = round((NothernNLBusinesses$KLFinancieleDienstenOnroerendGoed_169 / NothernNLBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "MN - Business Services" = round((NothernNLBusinesses$MNZakelijkeDienstverlening_170 / NothernNLBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "RU - Culture, Leisure and other Industries" = round((NothernNLBusinesses$RUCultuurRecreatieOverigeDiensten_171 / NothernNLBusinesses$BedrijfsvestigingenTotaal_164), digits = 2))

NothernNLBusinesses <- NothernNLBusinesses %>%
  gather("Industry_Sector", "Percentage" , "A - Agriculture, Forest Management and Fishing":"RU - Culture, Leisure and other Industries") %>%
  select(Perioden_numeric, Industry_Sector, Percentage, BedrijfsvestigingenTotaal_164)%>%
  rename(Period = Perioden_numeric, 
         Total_Businesses = BedrijfsvestigingenTotaal_164)

GroningenBusinesses <- regionalkeyfigures %>%
  select(RegioS, Perioden_numeric, BedrijfsvestigingenTotaal_164, ALandbouwBosbouwEnVisserij_165, BFNijverheidEnEnergie_166, GIHandelEnHoreca_167, HJVervoerInformatieEnCommunicatie_168, KLFinancieleDienstenOnroerendGoed_169, MNZakelijkeDienstverlening_170, RUCultuurRecreatieOverigeDiensten_171)%>%
  filter(Perioden_numeric < 2021, Perioden_numeric > 2012)%>%
  filter(RegioS == "Groningen")

GroningenBusinesses <- GroningenBusinesses %>%
  mutate(
    "A - Agriculture, Forest Management and Fishing" = round((GroningenBusinesses$ALandbouwBosbouwEnVisserij_165 / GroningenBusinesses$BedrijfsvestigingenTotaal_164), digits = 2), 
    "BF - Industry and Energy" = round((GroningenBusinesses$BFNijverheidEnEnergie_166 / GroningenBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "GI - Commerce and Hospitality" = round((GroningenBusinesses$GIHandelEnHoreca_167 / GroningenBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "HJ - Information and Communication" = round((GroningenBusinesses$HJVervoerInformatieEnCommunicatie_168 / GroningenBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "KL - Financial Services Regarding Real Estate " = round((GroningenBusinesses$KLFinancieleDienstenOnroerendGoed_169 / GroningenBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "MN - Business Services" = round((GroningenBusinesses$MNZakelijkeDienstverlening_170 / GroningenBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "RU - Culture, Leisure and other Industries" = round((GroningenBusinesses$RUCultuurRecreatieOverigeDiensten_171 / GroningenBusinesses$BedrijfsvestigingenTotaal_164), digits = 2))

GroningenBusinesses <- GroningenBusinesses %>%
  gather("Industry_Sector", "Percentage" , "A - Agriculture, Forest Management and Fishing":"RU - Culture, Leisure and other Industries") %>%
  select(Perioden_numeric, Industry_Sector, Percentage, BedrijfsvestigingenTotaal_164)%>%
  rename(Period = Perioden_numeric, 
         Total_Businesses = BedrijfsvestigingenTotaal_164)

FryslandBusinesses <- regionalkeyfigures %>%
  select(RegioS, Perioden_numeric, BedrijfsvestigingenTotaal_164, ALandbouwBosbouwEnVisserij_165, BFNijverheidEnEnergie_166, GIHandelEnHoreca_167, HJVervoerInformatieEnCommunicatie_168, KLFinancieleDienstenOnroerendGoed_169, MNZakelijkeDienstverlening_170, RUCultuurRecreatieOverigeDiensten_171)%>%
  filter(Perioden_numeric < 2021, Perioden_numeric > 2012)%>%
  filter(RegioS == "Fryslân")

FryslandBusinesses <- FryslandBusinesses %>%
  mutate(
    "A - Agriculture, Forest Management and Fishing" = round((FryslandBusinesses$ALandbouwBosbouwEnVisserij_165 / FryslandBusinesses$BedrijfsvestigingenTotaal_164), digits = 2), 
    "BF - Industry and Energy" = round((FryslandBusinesses$BFNijverheidEnEnergie_166 / FryslandBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "GI - Commerce and Hospitality" = round((FryslandBusinesses$GIHandelEnHoreca_167 / FryslandBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "HJ - Information and Communication" = round((FryslandBusinesses$HJVervoerInformatieEnCommunicatie_168 / FryslandBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "KL - Financial Services Regarding Real Estate " = round((FryslandBusinesses$KLFinancieleDienstenOnroerendGoed_169 / FryslandBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "MN - Business Services" = round((FryslandBusinesses$MNZakelijkeDienstverlening_170 / FryslandBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "RU - Culture, Leisure and other Industries" = round((FryslandBusinesses$RUCultuurRecreatieOverigeDiensten_171 / FryslandBusinesses$BedrijfsvestigingenTotaal_164), digits = 2))

FryslandBusinesses <- FryslandBusinesses %>%
  gather("Industry_Sector", "Percentage" , "A - Agriculture, Forest Management and Fishing":"RU - Culture, Leisure and other Industries") %>%
  select(Perioden_numeric, Industry_Sector, Percentage, BedrijfsvestigingenTotaal_164)%>%
  rename(Period = Perioden_numeric,
         Total_Businesses = BedrijfsvestigingenTotaal_164)

DrentheBusinesses <- regionalkeyfigures %>%
  select(RegioS, Perioden_numeric, BedrijfsvestigingenTotaal_164, ALandbouwBosbouwEnVisserij_165, BFNijverheidEnEnergie_166, GIHandelEnHoreca_167, HJVervoerInformatieEnCommunicatie_168, KLFinancieleDienstenOnroerendGoed_169, MNZakelijkeDienstverlening_170, RUCultuurRecreatieOverigeDiensten_171)%>%
  filter(Perioden_numeric < 2021, Perioden_numeric > 2012)%>%
  filter(RegioS == "Drenthe")

DrentheBusinesses <- DrentheBusinesses %>%
  mutate(
    "A - Agriculture, Forest Management and Fishing" = round((DrentheBusinesses$ALandbouwBosbouwEnVisserij_165 / DrentheBusinesses$BedrijfsvestigingenTotaal_164), digits = 2), 
    "BF - Industry and Energy" = round((DrentheBusinesses$BFNijverheidEnEnergie_166 / DrentheBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "GI - Commerce and Hospitality" = round((DrentheBusinesses$GIHandelEnHoreca_167 / DrentheBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "HJ - Information and Communication" = round((DrentheBusinesses$HJVervoerInformatieEnCommunicatie_168 / DrentheBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "KL - Financial Services Regarding Real Estate " = round((DrentheBusinesses$KLFinancieleDienstenOnroerendGoed_169 / DrentheBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "MN - Business Services" = round((DrentheBusinesses$MNZakelijkeDienstverlening_170 / DrentheBusinesses$BedrijfsvestigingenTotaal_164), digits = 2),
    "RU - Culture, Leisure and other Industries" = round((DrentheBusinesses$RUCultuurRecreatieOverigeDiensten_171 / DrentheBusinesses$BedrijfsvestigingenTotaal_164), digits = 2))

DrentheBusinesses <- DrentheBusinesses %>%
  gather("Industry_Sector", "Percentage" , "A - Agriculture, Forest Management and Fishing":"RU - Culture, Leisure and other Industries") %>%
  select(Perioden_numeric, Industry_Sector, Percentage, BedrijfsvestigingenTotaal_164)%>%
  rename(Period = Perioden_numeric,
         Total_Businesses = BedrijfsvestigingenTotaal_164)

#to get the economic data graph
economic_indicators <- read_csv("economic-indicators.csv", col_types = cols(Perioden = col_character(),Totalen = col_integer()))

economic_indicators <- economic_indicators %>% 
  rename(
    Total = Totalen,
    Period = Perioden
  )

#Benefit recipients data manipulation
Benefit_recipients <- economic_indicators %>% 
  filter(Onderwerp == "Uitkeringsontvangers totaal") %>% 
  filter(Region != "Nederland") %>% 
  filter(!is.na(Total))

Benefit_recipients$Region <- recode(Benefit_recipients$Region,
                                    "Groningen (PV)" = "Groningen",
                                    "Drenthe (PV)" = "Drenthe",
                                    "Fryslân (PV)" =  "Fryslân")

Groningen1 <- Benefit_recipients %>% filter(Region == "Groningen") 
Drenthe1 <- Benefit_recipients %>% filter(Region == "Drenthe") 
Fryslan1 <- Benefit_recipients %>% filter(Region == "Fryslân")

#Unemployment data manipulation
Unemployment <- economic_indicators %>% 
  filter(Onderwerp == "Werkloosheid totaal") %>% 
  filter(Region != "Nederland") %>% 
  filter(!is.na(Total))

Unemployment$Region <- recode(Unemployment$Region,
                              "Groningen (PV)" = "Groningen",
                              "Drenthe (PV)" = "Drenthe",
                              "Fryslân (PV)" =  "Fryslân")

Groningen2 <- Unemployment %>% filter(Region == "Groningen") 
Drenthe2 <- Unemployment %>% filter(Region == "Drenthe") 
Fryslan2 <- Unemployment %>% filter(Region == "Fryslân")

#GDP per capita data manipulation
Economic_indicatorsBPP1 <- economic_indicators

Economic_indicatorsBPP1$Region <- recode (Economic_indicatorsBPP1$Region,
                                          "Groningen (PV)" = "Groningen",
                                          "Drenthe (PV)" = "Drenthe",
                                          "Fryslân (PV)" =  "Fryslân")

BBP <- Economic_indicatorsBPP1 %>% 
  filter(Onderwerp == "Bbp per inwoner in euro")

GroningenBBP <- Economic_indicatorsBPP1 %>% 
  filter(Region == "Groningen") %>%
  filter(Onderwerp == "Bbp per inwoner in euro")

DrenghteBBP <- Economic_indicatorsBPP1 %>% 
  filter(Region == "Drenthe") %>%
  filter(Onderwerp == "Bbp per inwoner in euro")

FryslândBBP  <- Economic_indicatorsBPP1 %>%
  filter(Region == "Fryslân") %>%
  filter(Onderwerp == "Bbp per inwoner in euro")

NederlandBBP  <- Economic_indicatorsBPP1 %>% 
  filter(Region == "Nederland") %>%
  filter(Onderwerp == "Bbp per inwoner in euro")

#Employment data manipulation
employment <- economic_indicators %>% 
  filter(Onderwerp == "Werkzame personen totaal x 1000") %>% 
  filter(Region != "Nederland")

employment$Region <- recode (employment$Region,
                             "Groningen (PV)" = "Groningen",
                             "Drenthe (PV)" = "Drenthe",
                             "Fryslân (PV)" =  "Fryslân")

groningen_emp <- employment %>% filter(Region == "Groningen")
drenthe_emp <- employment %>% filter(Region == "Drenthe")
friesland_emp <- employment %>% filter(Region == "Fryslân")

#primary income data manipulation
incomes <- economic_indicators %>% 
  filter(Onderwerp == "Primair inkomen (netto) per inwoner in euro") %>% 
  filter(Region != "Nederland")

incomes$Region <- recode (incomes$Region,
                          "Groningen (PV)" = "Groningen",
                          "Drenthe (PV)" = "Drenthe",
                          "Fryslân (PV)" = "Fryslan")

groningenincomes <- incomes %>% 
  filter(Region == "Groningen")
drentheincomes <- incomes %>% 
  filter(Region == "Drenthe")
frieslandincomes <- incomes %>% 
  filter(Region == "Fryslan")

#Belonging van weknemers data manipulation
Belonging_van_werknemers <- economic_indicators %>% 
  filter(Onderwerp == "Beloning van werknemers in mln euro") %>% 
  filter(Region != "Nederland") %>%
  filter(!is.na(Total))

Belonging_van_werknemers$Region <- recode (Belonging_van_werknemers$Region,
                                           "Groningen (PV)" = "Groningen",
                                           "Drenthe (PV)" = "Drenthe",
                                           "Fryslân (PV)" =  "Fryslân")

groningen_bvw <- Belonging_van_werknemers %>% 
  filter(Region == "Groningen")
drenthe_bvw <- Belonging_van_werknemers %>% 
  filter(Region == "Drenthe")
friesland_bvw <- Belonging_van_werknemers %>% 
  filter(Region == "Fryslân")  

groningen_emp <- groningen_emp %>% 
  filter(Period < 2020)
drenthe_emp <- drenthe_emp %>% 
  filter(Period < 2020)
friesland_emp <- friesland_emp %>% 
  filter(Period < 2020)


groningen_bvw <- cbind(groningen_bvw, pop = groningen_emp$Total)
drenthe_bvw <- cbind(drenthe_bvw, pop = drenthe_emp$Total)
friesland_bvw <- cbind(friesland_bvw, pop = friesland_emp$Total)

groningen_bvw <- transform(groningen_bvw, avg = Total/pop)
drenthe_bvw <- transform(drenthe_bvw, avg = Total/pop)
friesland_bvw <- transform(friesland_bvw, avg = Total/pop)

groningen_bvw[["Total"]] <- groningen_bvw[["avg"]]
drenthe_bvw[["Total"]] <- drenthe_bvw[["avg"]]
friesland_bvw[["Total"]] <- friesland_bvw[["avg"]]


nl_bvw <- economic_indicators %>% 
  filter(Onderwerp == "Beloning van werknemers in mln euro") %>% 
  filter(Region == "Nederland") %>%
  filter(!is.na(Total))

nl_emp <- economic_indicators %>% 
  filter(Onderwerp == "Werkzame personen totaal x 1000") %>% 
  filter(Region == "Nederland", Period < 2020)

nl_bvw <- cbind(nl_bvw, pop=nl_emp$Total)
nl_bvw <- transform(nl_bvw, avg = Total/pop)
nl_bvw[["Total"]] <- nl_bvw[["avg"]]

#gross added value manipulation
values <- economic_indicators %>% 
  filter(Onderwerp == "Bruto toegevoegde waarde, volumemutaties in percentages") %>% 
  filter(Region != "Nederland")

values$Region <- recode (values$Region,
                         "Groningen (PV)" = "Groningen",
                         "Drenthe (PV)" = "Drenthe",
                         "Fryslân (PV)" = "Fryslan")

groningengad <- values %>% 
  filter(Region == "Groningen")
drenthegad <- values %>% 
  filter(Region == "Drenthe")
frieslandgad <- values %>% 
  filter(Region == "Fryslan")

#socialism data manipulation
socials <- economic_indicators %>% 
  filter(Onderwerp == "Bijstand totaal (tot AOW-leeftijd)") %>% 
  filter(Region != "Nederland") %>% filter(!is.na(Total))

socials$Region <- recode (socials$Region,
                          "Groningen (PV)" = "Groningen",
                          "Drenthe (PV)" = "Drenthe",
                          "Fryslân (PV)" = "Fryslan")

groningensocial <- socials %>% filter(Region == "Groningen")
drenthesocial <- socials %>% filter(Region == "Drenthe")
frieslandsocial <- socials %>% filter(Region == "Fryslan")

#To get the data for business confidence
Business_confidence <- cbs_get_data(id = "84303NED",
                                    select = c("Marges", "RegioS", "Perioden", "Ondernemersvertrouwen_1"),
                                    RegioS = has_substring(c("PV20",  "PV21" , "PV22")) ,
                                    Marges = "MW00000")


Business_confidence <- Business_confidence %>%
  rename(Region = RegioS,
         Period = Perioden,
         Margin = Marges,
         Confidence= Ondernemersvertrouwen_1) %>%
  mutate(Region = case_when(
    Region == "PV20  " ~ "Groningen",
    Region == "PV21  " ~ "Fryslân",
    Region == "PV22  " ~ "Drenthe"))

GroningenBC <- Business_confidence %>% filter(Region == "Groningen") 
DrentheBC <- Business_confidence %>% filter(Region == "Drenthe") 
FryslanBC <- Business_confidence %>% filter(Region == "Fryslân")

#to get the data for the earthquakes 
all_induced <- read_csv("all_induced.csv", col_types = cols(Perioden = col_character(), Totalen = col_character()))

data <- all_induced

#to get the geodata
municipalities <- geojson_read("provinces.geojson", what = "sp")
Groningen <- geojsonR::shiny_from_JSON("Groningen.geojson")
Fryslan <- geojsonR::shiny_from_JSON("Frysland.geojson")
Drenthe <- geojsonR::shiny_from_JSON("Drenthe.geojson")

#make the shapefiles for the three Region
Groningen_municipality <- municipalities[municipalities@data$name == "Groningen", ]
Drenthe_municipality <- municipalities[municipalities@data$name == "Drenthe", ]
Frysland_municipality <- municipalities[municipalities@data$name == "Friesland (Fryslân)", ]

#define color for the depth of the earthquakes 
data$depth_type <-  ifelse(data$DEPTH <=2, "0-2km",
                           ifelse(data$DEPTH>2 &data$DEPTH<=3,"2-3km",
                                  ifelse(data$DEPTH>3,"more than 3km","Wrong value, should not be here")))

#define the color of for the mag of the earthquakes
pal <- colorNumeric(palette = c('gold', 'orange', 'dark orange', 'orange red', 'red', 'dark red'), domain = data$MAG)

pal2 <- colorFactor(palette = c('red', 'blue', 'yellow'), domain = data$depth_type)


#CODE FOR UI INTERFACE

ui <- dashboardPage(
  dashboardHeader(title = strong("The demographics & economics of the Nothern Netherlands"), titleWidth = 800),
  dashboardSidebar(
    sidebarMenu(
      id = "tabs",
      menuItem(strong("Home"), tabName = "tab1", icon = icon("home")),
      menuItem(strong("Demographics"), icon = icon("address-card"), tabName = "tab2", 
               menuSubItem("Population Size", tabName = "subitem1"),
               menuSubItem("Age", tabName = "subitem2"),
               menuSubItem("Birth rate", tabName ="subitem16"),
               menuSubItem("Mortality Rate", tabName = "subitem3"),
               menuSubItem("Educational", tabName = "subitem4")),
      menuItem(strong("Economic trends"), icon = icon("hand-holding-usd"),
               tabName = "tab3", 
               menuSubItem("Industry Distribution", tabName = "subitem15"),
               menuSubItem("GDP per Capita", tabName = "subitem5"),
               menuSubItem("Employment", tabName = "subitem6"),
               menuSubItem("Unemployment", tabName = "subitem7"),
               menuSubItem("Income", tabName = "subitem8"),
               menuSubItem("Business Confidence", tabName = "subitem9"),
               menuSubItem("Gross Added Value", tabName = "subitem12"),
               menuSubItem("Benefit Recipients", tabName = "subitem13"),
               menuSubItem("Compensation of employees", tabName = "subitem14"),
               menuSubItem("Social assistance", tabName = "subitem17")),
      menuItem("Earthquakes", icon = icon("globe-europe"), tabName = "tab4"),
      menuItem("Glossary", tabName = "tab5", icon = icon("book")),
      menuItem("Downloads", tabName = "tab6", icon = icon("download")),
    textOutput("res")
    )),
  
  dashboardBody(
    
    dashboardthemes::shinyDashboardThemes(theme = "poor_mans_flatly"),
    tabItems(
      tabItem(tabName = "subitem17",
              h2("Social assistance"),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(width = 12,
                               p("This graph shows the total social assistance compensations given by each province in thousand EUR. 
                               This number includes all social assistance payments made until pension age, which according to the General 
                               Old Age Pensions Act (AOW) is 66 years and 7 months (until 2023). Data is taken from 2007 until 2019. 
                               Previous to 2007, social assistance was only measured at the national level."), 
                              p("Specific numbers per region per year can be shown by moving the", 
                              strong("mouse"), "toward the corresponding points in the graph."), 
                               style = "background-color: aliceblue"),
                  mainPanel(width = 12,
                            plotlyOutput("psocials")
                  )
                )
              )
          ),
      tabItem(tabName = "subitem16",
              h2("Birth rate content"),
              fluidPage(
                sidebarPanel(width =12,
                             p("Graph aims at picturing yttal number of individuals (y-axis) who were born in a specific year (x-axis), ranging from 2002 to 2020, for the Region Groningen, Drenthe, and Fryslân. 
                               The number is specified in the bars. The number is specified in the bars. The value on the Y-axis shows the birth ratio. 
                               This ratio has been calculated by dividing the counts of death by the total population multiplied by 100."),
                             p("The", strong("button"), "can be used to select one of the three Region."), 
                             p("The graph will automatically update itself once the button or select input is clicked on."),
                             radioButtons(
                               inputId = "choose",
                               label =  tags$span(style="color: blue;","Region:"),
                               choices = c("Groningen", "Drenthe", "Fryslân")),
                             style = "background-color: aliceblue"),
                mainPanel(width = 12,
                          plotOutput("Birthrate")
                )
              )
      ),
      tabItem(tabName = "tab5",
              h2("Glossary list explaining the terms"),
              fluidPage(
                mainPanel(width = 12,
                           p(strong("Business confidence"), ": Sentiment indicator for private enterprises for the short-term development of the gross domestic product based on opinions and expectations of private companies."),
                           p(strong("Unemployed persons"), ": People who don’t have a paid job, who have recently looked for work and are directly employable. 
                  This definition takes into account the people who currently live in the Netherlands and consider habitants between the age of 15 and 75. 
                  A paid job considers every work activity, regardless of the working hours. "),
                           p(strong("Unemployment allowances"), ": Benefits under the Unemployment Insurance Act (WW). "),
                           p(strong("Benefit recipients"), ": Total number of persons who are rightfull for one of the following benefits / allowances:  Unemployment Act (WW), Social Assistance Act (PW), welfare-related Act (IOAW, IOAZ, Bbz), Disability Act (WAO, WIA, WAZ, Wajong, Wet Wajong) or the General Old Age Act (AOW)."),
                           p(strong("Compensation of employees"), ": The compensation of employees has two components: wages on the one hand and social contributions paid by employers on the other. The wages include the wage tax withheld by the employer and the social security contributions that are borne by the employees. In addition to the periodic wages paid directly to employees, wages also include supplements to this (such as bonuses, overtime compensation, tips and commission), wages in kind (such as free housing, free food, 'company car', discount on childcare, interest benefit, cheap travel) and the holiday allowance. Certain allowances for costs incurred by employees in connection with employment, such as reimbursement for the costs of commuting, are also included in wages. The social contributions are the statutory social insurance contributions, pension contributions, other private social contributions and imputed social contributions. These premiums are borne by employers, employees, the self-employed or non-workers."),
                           p(strong("Educational types"), "The Dutch term for secondary Vocational Education and Training (VET) is middelbaar beroepsonderwijs. 
                           The Dutch usually refer to it by its abbreviation mbo. Pre-vocational education and training is known as voorbereidend middelbaar beroepsonderwijs (vmbo). 
                           There are two types of higher education in the Netherlands: research-oriented and profession-oriented. 
                           Research-oriented education (wetenschappelijk onderwijs, WO) is traditionally offered by research universities. Higher professional education (hoger beroepsonderwijs, HBO) is offered by universities of applied sciences (hogescholen)."),
                           p(strong("Gross added value"), " the value of output minus the value of intermediate consumption; it is a measure of the contribution to GDP made by an individual producer, industry or sector. It is calculated as the Gross domestic product plus subsidies minus taxes"),
                           p(strong("Gross domestic product per capita"), "measures a country's economic output per person and is calculated by dividing the GDP of a country by its population. GDP is equal to the sum of the gross value added of all resident institutional units engaged in production, plus any taxes on products and minus any subsidies on products. In other words, it is the total monetary or market value of all the finished goods and services produced within a country’s borders in a specific time period (in this case annually)."),
                           p(strong("Benefit recipients"), " are individuals who receive unemployment benefits, social assistance or other social provisions, as well as people 
                           on a sickness benefit or people with occupational disabilities."),
                          p(strong("Social assistance"), "the benefit (toeslagen) system is designed to support people on low incomes by helping them cover basic living costs such as rent, helath insurance, childcare and raising children."),
                          p(strong("Net primary income per capita"), "The income of the primary job (most hours worked or if equal to another job, the highest paying) of a person. Technically including the dividends and capital gains.")
                )
              )
            ),
      tabItem(tabName = "tab6",
              h2("Downloads"),
                mainPanel(width = 12,
                h4("Demographics"),
                p("With this button you can download the data we've used for the demographic themed graphs."), downloadLink("download_demographics"),
                h4("Economics"),
                p("With this button you can download the data we've used for the economic themed graphs."), downloadLink("download_economics"),
                h4("Business Confidence"),
                p("With this button you can download the data we've used for the business confidence graph."), downloadLink("download_business_confidence"),
                h4("Regional figures"),
                p("With this button you can download the data we've used for the regional key figures."), downloadLink("download_regionalfigures"),
                h4("Earthquakes"),
                p("With this button you can download the data we've used for the earthquake-maps."), downloadLink("download_earthquake")
                )
              ),
      tabItem(tabName = "tab1",
              h2("Home Content"),
              fluidPage(
                mainPanel(width = 12,
                          p(tags$img(src = "rug_logo.png", height = 117, width = 424),
                            tags$img(src = "datawise_logo.png", height = 120)),
                          p(" "),
                          p("Welcome to the dashboard visualizing the demographic and economic situation of the Northern Netherlands. 
                          The Northern Netherlands regions considered in this case are: Groningen, Drenthe, and Fryslân."),
                          p("On behalf of the CBS, this dashboard shows the economic performance of the Northern region of the Netherlands. 
                            This dashboard shows the demographic developments such as birth and education. 
                            Moreover, it gives insights into the current economic situation of these provinces. 
                            This information is shown next to the visualization of the earthquakes. 
                            A question raised could be: has the occurrence of regular earthquakes had an effect on the economic performance of this region? 
                            As a disclaimer, the epistemology of the evidence found on this dashboard is based on correlation instead of causation. 
                            Therefore, no scientifically based conclusions can be drawn from this dashboard, however, they can inspire institutions to perform further research regarding these relationships."),
                          p("The development of this dashboard has been done by University of Groningen students, of the Minor Data Wise: Data Science in Society. 
                          These students are: Xinyi Zhou, Carmen Oudejans, Sidharthan Babu, Guglielmo Caridi and Isa van Schie. 
                          We have created this dashboard with the help of two supervisors who are: Rosanne Pronk (CBS) and Stepan Zaretckii (RUG)."),
                          p("The Dashboard has been created by making use of the application Shiny R. See the tab called", strong("“Download”"), "for the link regarding the complete code of our dashboard. 
                            At this page the sources to the data will also be displayed. Most of the data used to create the visualizations in this dashboard has been collected from the open repository of the CBS, Statline."),
                          p(tags$img(src = "bikeroute.png", height = 320)) 
                          )
                )
              ),
      tabItem(tabName = "tab2",
              h2("Demographics content")
      ),
      tabItem(tabName = "tab3",
              h2("Economic trends content")
      ),
      tabItem(tabName = "tab4",
              h2("Earthquakes in the Northern Netherlands"),
              fluidPage(
                mainPanel(width = 12,
                          p("This map shows the occurrence of earthquakes in the Netherlands. The data comes from a dataset provided by the", span("KNMI Data Platform", style = "color:blue"), "and includes the earthquakes from 26-12-1985 till 24-11-2021."),
                          p("The", strong("slider input"), "can be used to show the occurrence of the earthquakes along the time."),
                          p("Additionally,", strong("the depth map"), "can be clicked to see the depth of the earthquake. The depth categories are 0-2 km, 2-3 km and more than 3 km. As can be seen when studying the map, most earthquakes belong to the category of 2-3 km."), 
                          p("As can be seen when clicking on the", strong("heat map"), "most earthquakes occur in the Northern Netherlands. The provinces Groningen, Fryslând and Drenthe have been highlighted with a green colour."),
                          p("By placing the", strong("mouse"), "on a circle, you can receive information about the magnitude and location of the earthquake. The larger the magnitude, the bigger the circle of the data point."),
                          p("The", strong("zooming"), "function can be used to receive a different view of the map."),
                          #this will create a space for us to display our map
                          sliderInput(inputId = "date", "Date:", min = 
                                        as.Date("1986-12-26"), max = as.Date("2021-11-24"), 
                                      value = as.Date("1986-12-26"), width = "600px"),
                          leafletOutput("mymap", width = 600), 
                          #this allows me to put the checkmarks ontop of the map to allow people to view earthquake depth or overlay a heatmap
                          absolutePanel(top = 500, left = 20, 
                                        checkboxInput("markers", "Depth", FALSE),
                                        checkboxInput("heat", "Heatmap", FALSE)
                          )
                )
              )
      ),
      tabItem(tabName = "subitem1",
              h2("Population size"),
              fluidPage(
                sidebarPanel(width = 12,
                             p("Generated maps and line graph aim at representing the total number of people in the population in the concerned regions. 
                          When observing the maps it can be seen illustrated the separation by binary sexuality of the populations. The line charts give an overview of the changes in population size throughout the years."),
                             style = "background-color: aliceblue"),
                mainPanel(width =12,
                          
                          plotlyOutput("plotPopulation"),
                          
                          sliderInput(inputId = "PopuSlider", label = "Year:", 
                                      min = min(regionalkeyfigures$Perioden_numeric), max = max(regionalkeyfigures$Perioden_numeric), value = max(regionalkeyfigures$Perioden_numeric), 
                                      step = 1, ticks = TRUE, width = "600px", dragRange = FALSE, sep = ""),
                          
                          leafletOutput("population_NNLRegions"), 
                          leafletOutput("popugenders_NNLRegions")
                )
              )
            ),
      tabItem(tabName = "subitem2",
              h2("Age"),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(width = 12,
                               p("This graph shows the percentage of individuals (x-axis) belonging to a specific age group (y-axis) for the Region Groningen, Drenthe, and Fryslân. The numbers on the right show the total count of individuals belonging to the age category."),
                               p("The", strong("button"), "can be used to select one of the three Region."),
                               p("The", strong("select time Period"), "can be used to select a year, ranging from 1995 to 2021."), 
                               p("The graph will automatically update itself once the button or select input is clicked on."),
                               radioButtons(
                                 inputId = "peak",
                                 label =  tags$span(style="color: blue;","Region:"),
                                 choices = c("Groningen", "Drenthe", "Fryslân")),
                               selectInput(
                                 inputId =  "date_from", 
                                 label =  tags$span(style="color: blue;","Select time Period:"),
                                 choices = 1995:2021,
                                 selected = "2021"),
                               style = "background-color: aliceblue"),
                  mainPanel(width = 12,
                            plotOutput("Age")
                  )
                )
              )
      ),
      tabItem(tabName = "subitem3",
              h2("Mortality Rate"),
              fluidPage(
                sidebarPanel(width =12,
                             p("This graph shows the Total number of individuals (y-axis) who have died in a specific year (x-axis), ranging from 2002 to 2020, for the Region Groningen, Drenthe, and Fryslân. 
                               The number is specified in the bars.The number is specified in the bars. The value on the Y-axis shows the mortality ratio. 
                               This ratio has been calculated by dividing the counts of death by the total population multiplied by 100."),
                             p("The", strong("button"), "can be used to select one of the three Region."), 
                             p("The graph will automatically update itself once the button or select input is clicked on."),
                             radioButtons(
                               inputId = "peak2",
                               label =  tags$span(style="color: blue;","Region:"),
                               choices = c("Groningen", "Drenthe", "Fryslân")),
                             style = "background-color: aliceblue"),
                mainPanel(width = 12,
                          plotOutput("Mortality", click = "plot_click"),
                          verbatimTextOutput("info")
                )
              )
      ),
      tabItem(tabName = "subitem4",
              h2("Educational types"),
              fluidPage(
                fluidRow(
                  column(
                    width = 12,
                    p("Line graphs aim at comparing the number of graduates in the region by plotting the number of 
                    graduates on the y-axis vs the year on the x-axis. The four advanced levels of education VO, MBO, 
                    HBO and WO are considered. See the glossary list for more further information about the different 
                    types of education."),
                    style = "background-color: aliceblue",
                    box(
                      width =12,
                      style = "background-color: aliceblue",
                      plotlyOutput("ploteduVO"),
                      plotlyOutput("ploteduMBO"),
                      plotlyOutput("ploteduHBO"),
                      plotlyOutput("ploteduWO")
                    )
                  )
                )
              )
      ),
      tabItem(tabName = "subitem15",
              h2("Industry Distribution"),
              fluidPage(
                fluidRow(
                  column(
                    width = 12,
                    style = "background-color: aliceblue",
                    p("Pie charts aim at visualizing division of businesses interest in the region and provinces, while the line graph depicts the total number of businesses in the provinces. 
                      By interaction with the slider the input year for the pie charts can be chosen, changes throughout the depicted period are minimal but do provide an image of the business interests in the region."),
                    box(
                      width = 12,
                      
                      plotlyOutput("BusinessPlotLine"),
                    
                      sliderInput(inputId = "BussSlider", label = "Year:", 
                                  min = min(NothernNLBusinesses$Period), max = max(NothernNLBusinesses$Period), value = max(NothernNLBusinesses$Period), 
                                  step = 1, ticks = TRUE, width = "600px", dragRange = FALSE, sep = ""),
                      
                      plotOutput("BusinessPlotNL"),
                      plotOutput("BusinessPlotGroningen"),
                      plotOutput("BusinessPlotFrysland"),
                      plotOutput("BusinessPlotDrenthe"))
                  )
                )
              )
      ),
      tabItem(tabName = "subitem5",
              h2("Gross domestic product per capita in the Northern Netherlands"),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(width = 12,
                               p("This graph visualizes the average GDP per capita (y-axis) for the Regions Groningen, Drenthe, and Fryslân. The purple dotted line represents the average GDP per capita in the Netherlands. The data is visualized over a time scale from 1995 to 2020 (x-axis). The years 2019 and 2020 include an asterisk, because the numbers are preliminary."), 
                               p("The data can be shown on a", strong("hover"), "for one Region, but also to compare all the four Region on a hover. This can be selected with the mouse in the upper right corner. Additionally, there are some zooming in and out functions provided by", span("Plotly", style = "color:blue")), 
                               p("Interestingly, the effect of the financial crisis of 2007–2008, also called subprime mortgage crisis in the Netherlands, can be seen by the decline in GDP per capita in the year 2008. This crisis originated in the United States as a result of the collapse of the U.S. housing market."),
                               style = "background-color: aliceblue"),
                  mainPanel(width = 12,
                            plotlyOutput("plotBBP")
                  )
                )
              )
      ),
      tabItem(tabName = "subitem6",
              h2("Employment"),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(width = 12,
                               p("This graph shows the number of employed persons (y-axis) in Groningen, Drenthe and Fryslân from the year 1995 to 2019 (x-axis)."), 
                               p("The employed persons include all resident and non-resident persons who have one or more paid jobs as an employee and/or self-employed person at an economic unit established in the Netherlands."), 
                               p("Specific numbers per region per year can be shown by moving the", strong("mouse"), "toward the corresponding points in the graph."),
                               style = "background-color: aliceblue"),
                  mainPanel(width = 12,
                            plotlyOutput("plot10")
                  )
                ) 
              )
      ),
      tabItem(tabName = "subitem7",
              h2("Unemployment"),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(width = 12,
                                p("This graph shows the number of unemployed persons (y-axis) in Groningen, Drenthe and Fryslân from the year 2007 to 2019 (x-axis). 
                              It is based on the data about the number of people who have an allowance under the Unemployment Insurance Act (in Dutch: Werkloosheidswet)."),
                                p("By sliding across the line graph with your cursor, more information for each datapoint is shown. "), 
                                style = "background-color: aliceblue"),
                  mainPanel(width = 11,
                            plotlyOutput("plotUnemployment"))
                )
              )
      ),
      tabItem(tabName = "subitem8",
              h2("Primary Income per Capita"),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(width = 12,
                               p("Primary income levels denote the average wages of primary sources 
                               of income. In this case, secondary modes of income (part-time work in excess 
                               of their full-time commitments) are discarded. If seperate part-time or full-time
                               commitments exist, the highest paying employment is considered."),
                               p("Primary income levels are used as opposed to total income to show how much an average worker can expect to be paid for their primary commitments. Included in this calculation is the gains made from capital investment and dividends."),
                               p("This graph shows the primary incomes between the three provinces from 2015 to 2018. All values are preliminary, and data since 2018 was not included in the graph due to discrepancies in the data."),
                               p("Specific numbers per region per year can be shown by moving the mouse toward 
                               the corresponding points in the graph."),
                               style = "background-color: aliceblue"),
                  mainPanel(width = 12,
                            plotlyOutput("primaryincome")
                  )
                ) 
              )
      ),
      tabItem(tabName = "subitem9",
              h2("Consumption"),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(width = 12, 
                               p("This graph shows the level of confidence businesses 
                            have on average in the province throughout the years 2014 to 2021. 
                            Business confidence is a mood indicator that indicates 
                            the direction in which the economy (gross domestic product, GDP) 
                            is expected to develop. In assessing the results, one can assume 
                            that the more optimistic or pessimistic the entrepreneurs are in their mood, 
                            the more the value of business confidence will deviate positively or negatively 
                            from the zero line and the greater the expectation that the development of GDP will 
                            increase or decrease in the coming months. The business confidence of a province is
                            a weighted average of the confidence indicators of the underlying industries/sectors
                            that together form a representative reflection of the total Dutch business community. 
                            For each business sector, information from the Netherlands Business Survey (COEN) is used 
                            for the composition of the Business Confidence."),
                               p("By sliding across the line graph with your cursor, more information for each datapoint is shown."),
                               style = "background-color: aliceblue"),
                  mainPanel(width = 12,
                            plotlyOutput("plotBusinessConfidence"))
                )
              )
      ),
      tabItem(tabName = "subitem12",
              h2("Gross added value"),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(width =12,
                               p("Gross added value is an economic productivity metric that measures the value 
                               added to the economy by a sector or region. Gross added value is related to GDP 
                               in that gross added value is the GDP less taxes and adds back subsidies that 
                               governments grant. Gross added value is favored over GDP because it shows economic efficiency 
                               of a sector or region due to its accountancy of inputs and intermediate consumption."),
                               p("This graph shows the gross added value between the three provinces from 1995 to 2020. 
                               2019 and 2020 figures are preliminary."),
                               p("Specific numbers per region per year can be shown by moving the mouse toward 
                               the corresponding points in the graph."),
                               style = "background-color: aliceblue"),
                  mainPanel(width = 12,
                            plotlyOutput("grossvalue")
                  ) 
                )
              )
      ),
      tabItem(tabName = "subitem13",
              h2("Benefit recipients"),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(width = 12,
                               p("This graph shows the number of benefit recipients, so the number of people 
                               who receive an allowance of any kind (y-axis) next to the years from 2007 to 2019 (x-axis). 
                               People must have  a Dutch identity, but do not have to live in the Netherlands."),
                               p("By sliding across the line graph with your cursor, more information for each datapoint 
                               is shown."),
                               p("As you can see, from 2012 to 2013 there is a steep increase in the number of benefit 
                                 recipients. Especially, benefit recipients from the healthcare sector, wholesale company, 
                                 metal sector, and transport industry increased. This was an effect of the economic crisis. 
                                 Additionally, there might have been some changes in restrictions for benefit payment."),
                               style = "background-color: aliceblue"),
                  mainPanel(width = 11,
                            plotlyOutput("plotBenefitR"))
                )
              )
      ),
      tabItem(tabName = "subitem14",
              h2( "Compensation of employees"),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(width = 12,
                               p("This graph shows compensation per employee in thousand euro (y-axis) in Groningen, Drenthe and Fryslân from the year 1995 to 2019 (x-axis). The purple dotted line represents national figures for the same time period."), 
                               p("The compensation of employees has two components: wages on the one hand and social contributions paid by employers on the other. The wages include the wage tax withheld by the employer and the social security contributions that are borne by the employees. In addition to the periodic wages paid directly to employees, wages also include supplements to this (such as bonuses, overtime compensation, tips and commission), wages in kind (such as free housing, free food, 'company car', discount on childcare, interest benefit, cheap travel) and the holiday allowance. Certain allowances for costs incurred by employees in connection with employment, such as reimbursement for the costs of commuting, are also included in wages. The social contributions are the statutory social insurance contributions, pension contributions, other private social contributions and imputed social contributions. These premiums are borne by employers, employees, the self-employed or non-workers."), 
                               p("Figures in this graph were calculated by dividing the total amount of compensation by the number of employed persons per region."),
                               p("Specific numbers per region per year can be shown by moving the", strong("mouse"), "toward the corresponding points in the graph."),
                               style = "background-color: aliceblue"),
                  mainPanel(width = 12,
                            plotlyOutput("plotBvw"))))))))

  




#CODE FOR SERVER INTERFACE

server <- function(input, output, session) {
  
  #POPULATION AND GENDER MAP
  
  output$population_NNLRegions <- renderLeaflet(
    
    leaflet(width = 650, height = 400) %>%
      setView(lng = 6, lat = 53.1, zoom = 8) %>%
      addTiles() %>%
      addGeoJSON(geojson = Groningen, weight = 1, fillColor = "#FF0000", fillOpacity = 0.1)%>%
      addGeoJSON(geojson = Fryslan, weight = 1, fillColor = "#52E74B", fillOpacity = 0.1)%>%
      addGeoJSON(geojson = Drenthe, weight = 1, fillColor = "#6854D8", fillOpacity = 0.1)%>%
      addCircleMarkers(data = Fryslankeyfigures, lng = 5.7, lat = 53.2, radius = ~Total_Population[Period == input$PopuSlider]/20000, color = "#FFA500", opacity = 1, fill = TRUE, fillOpacity = 1, label =  ~Total_Population[Period == input$PopuSlider], labelOptions = labelOptions(noHide = F, direction = "top", textsize = 20))%>%
      addCircleMarkers(data = Groningenkeyfigures, lng = 6.7, lat = 53.3, radius =  ~Total_Population[Period == input$PopuSlider]/20000, color = "#FFA500", opacity = 1, fill = TRUE, fillOpacity = 1, label =  ~Total_Population[Period == input$PopuSlider], labelOptions = labelOptions(noHide = F, direction = "top", textsize = 20))%>%
      addCircleMarkers(data = Drenthekeyfigures, lng = 6.6, lat = 52.8, radius =  ~Total_Population[Period == input$PopuSlider]/20000, color = "#FFA500", opacity = 1, fill = TRUE, fillOpacity = 1, label =  ~Total_Population[Period == input$PopuSlider], labelOptions = labelOptions(noHide = F, direction = "top", textsize = 20))%>%
      addLegend(position = "topright", colors = c("#FF0000", "#52E74B", "#6854D8"),  labels = c("Groningen", "Fryslân", "Drenthe"), title = "Region:")%>%
      addLegend(position = "bottomright", colors = "#FFA500",  labels = "Population")
  )
  
  output$popugenders_NNLRegions <- renderLeaflet(
    
    leaflet(width = 650, height = 400) %>%
      setView(lng = 6, lat = 53.1, zoom = 8) %>%
      addTiles() %>%
      addGeoJSON(geojson = Groningen, weight = 1, fillColor = "#FF0000", fillOpacity = 0.1)%>%
      addGeoJSON(geojson = Fryslan, weight = 1, fillColor = "#52E74B", fillOpacity = 0.1)%>%
      addGeoJSON(geojson = Drenthe, weight = 1, fillColor = "#6854D8", fillOpacity = 0.1)%>%
      addCircleMarkers(data = Fryslankeyfigures, lng = c(5.5, 5.9), lat = c(53.2, 53.2), radius = c(~Men[Period == input$PopuSlider]/20000, ~Women[Period == input$PopuSlider]/20000), color = c("#0000FF", "#FF0000"), opacity = 1, fill = TRUE, fillOpacity = 1, label = c(~Men[Period == input$PopuSlider], ~Women[Period == input$PopuSlider]), labelOptions = labelOptions(noHide = F, direction = "top", textsize = 20))%>%
      addCircleMarkers(data = Groningenkeyfigures, lng = c(6.5, 6.9), lat = c(53.3, 53.3), radius = c(~Men[Period == input$PopuSlider]/20000, ~Women[Period == input$PopuSlider]/20000), color = c("#0000FF", "#FF0000"), opacity = 1, fill = TRUE, fillOpacity = 1, label = c(~Men[Period == input$PopuSlider], ~Women[Period == input$PopuSlider]), labelOptions = labelOptions(noHide = F, direction = "top", textsize = 20))%>%
      addCircleMarkers(data = Drenthekeyfigures, lng = c(6.4, 6.8), lat = c(52.8, 52.8), radius = c(~Men[Period == input$PopuSlider]/20000, ~Women[Period == input$PopuSlider]/20000), color = c("#0000FF", "#FF0000"), opacity = 1, fill = TRUE, fillOpacity = 1, label = c(~Men[Period == input$PopuSlider], ~Women[Period == input$PopuSlider]), labelOptions = labelOptions(noHide = F, direction = "top", textsize = 20))%>%
      addLegend(position = "topright", colors = c("#FF0000", "#52E74B", "#6854D8"),  labels = c("Groningen", "Fryslân", "Drenthe"), title = "Region:")%>%
      addLegend(position = "bottomright", colors = c("#0000FF", "#FF0000"),  labels = c("Males", "Females"), title = "Gender:")
  )
  
  output$plotPopulation <- renderPlotly(
    ggplot(data = regionalkeyfigures, aes(x = Period, y = Total_Population, color = Region, group = 1)) +
      geom_line(data = Drenthekeyfigures, aes(x = Period, y = Total_Population, group = 1)) +
      geom_line(data = Groningenkeyfigures, aes(x = Period, y = Total_Population, group = 1)) +
      geom_line(data = Fryslankeyfigures, aes(x = Period, y = Total_Population, group = 1)) + 
      theme_bw() + 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.subtitle = element_text(size = 13, family = "Times",
                                     face = "italic"),
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_line(colour = "azure2"),
        panel.grid.minor.y = element_line(colour = "azure2"),
        panel.grid.major.x = element_blank(),
        axis.title = element_text(size = 12, face = "bold"),
        axis.text.x = element_text(angle = 40)
      ) +
      labs(
        x = "Years", y = "Number of People",
        title = "Population Size per Province",
        subtitle = c("Drenthe", "Fryslând", "Groningen"),
        color = "Region" )
  )
  
  
  #AGE GRAPH
  dataInput <- reactive({
    Age <- switch(input$peak,  
                  "Drenthe" = Age %>% filter(Region == "Drenthe"),
                  "Groningen" = Age %>% filter(Region == "Groningen"),
                  "Fryslân" = Age %>% filter(Region == "Fryslân"))
    switch(input$date_from,
           "1995" = Age %>% filter(Period == "1995"),
           "1996" = Age %>% filter(Period == "1996"),
           "1997" = Age %>% filter(Period == "1997"),
           "1998" = Age %>% filter(Period == "1998"),
           "1999" = Age %>% filter(Period == "1999"),
           "2000" = Age %>% filter(Period == "2000"),
           "2001" = Age %>% filter(Period == "2001"),
           "2002" = Age %>% filter(Period == "2002"),
           "2003" = Age %>% filter(Period == "2003"),
           "2004" = Age %>% filter(Period == "2004"),
           "2005" = Age %>% filter(Period == "2005"),
           "2006" = Age %>% filter(Period == "2006"),
           "2007" = Age %>% filter(Period == "2007"),
           "2008" = Age %>% filter(Period == "2008"),
           "2009" = Age %>% filter(Period == "2009"),
           "2010" = Age %>% filter(Period == "2010"),
           "2011" = Age %>% filter(Period == "2011"),
           "2012" = Age %>% filter(Period == "2012"),
           "2013" = Age %>% filter(Period == "2013"),
           "2014" = Age %>% filter(Period == "2014"),
           "2015" = Age %>% filter(Period == "2015"),
           "2016" = Age %>% filter(Period == "2016"),
           "2017" = Age %>% filter(Period == "2017"),
           "2018" = Age %>% filter(Period == "2018"),
           "2019" = Age %>% filter(Period == "2019"),
           "2020" = Age %>% filter(Period == "2020"),
           "2021" = Age %>% filter(Period == "2021"))
  })
  
  output$Age <- renderPlot({
    ggplot(dataInput(), aes(x = Subsubject, y = percentageX)) + 
      geom_bar(stat = "summary", fun = "mean", fill = "blue") +
      geom_text(aes(label=Total, x=Subsubject, y=11), colour="blue") +
      coord_flip() +
      scale_y_continuous(
        breaks = seq(0, 11.1, 0.5),
        limits = c(0, 11.1)
      ) +
      labs(
        title = "Number of cases per age category",
        subtitle = "Data about Groningen, Drenthe and Fryslând (Statline)",
        x = "Age categories",
        y = "Percentage of the total amount of people"
      ) +
      theme_minimal() +
      theme(
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.grid.major.x = element_line(colour = "azure2"),
        plot.title = element_text(face = "bold", size = 13),
        plot.subtitle = element_text(face = "italic"),
        axis.title = element_text(face = "bold", size = 13),
        axis.text.x = element_text(angle = 40)) +
      scale_x_discrete(
        labels = c(
          "0 to 5 years" = "0-5 years",
          "5 tot 10 jaar" = "5-10 years",
          "10 tot 15 jaar" = "10-15 years",
          "15 tot 20 jaar" = "15-20 years",
          "20 tot 25 jaar" = "20-25 years",
          "25 tot 30 jaar" = "25-30 years",
          "30 tot 35 jaar" = "30-35 years",
          "35 tot 40 jaar" = "35-40 years",
          "40 tot 45 jaar" = "40-45 years",
          "45 tot 50 jaar" = "45-50 years",
          "50 tot 55 jaar" = "50-55 years",
          "55 tot 60 jaar" = "55-60 years",
          "60 tot 65 jaar" = "60-65 years",
          "65 tot 70 jaar" = "65-70 years",
          "55 tot 60 jaar" = "55-60 years",
          "60 tot 65 jaar" = "60-65 years",
          "65 tot 70 jaar" = "65-70 years",
          "70 tot 75 jaar" = "70-75 years",
          "80 tot 85 jaar" = "80-85 years",
          "85 tot 90 jaar" = "85-90 years",
          "90 tot 95 jaar" = "90-95 years",
          "95 jaar of ouder" = "95+ years")
      ) 
  })
  
  #Mortality graph
  dataInput2 <- reactive({
    switch(input$peak2,  
           "Drenthe" = Mortality %>% filter(Region == "Drenthe"),
           "Groningen" = Mortality %>% filter(Region == "Groningen"),
           "Fryslân" = Mortality %>% filter(Region == "Fryslân"))
  })
  
  output$Mortality <- renderPlot({
    ggplot(dataInput2(), aes(x = Period, y = percentageY)) + 
      geom_bar(stat = "summary", fun = "mean", fill = "blue") +
      scale_y_continuous(
        breaks = seq(0, 1.3, 0.1),
        limits = c(0, 1.3)
      ) +
      geom_text(aes(label=Total, x=Period, y=0.9*percentageY), colour="aliceblue") +
      labs(
        title = "Number of deaths per year",
        subtitle = "Data about Groningen, Drenthe and Fryslând",
        x = "Periods",
        y = "Mortality ratio ((count / population) x 100)"
      ) +
      theme_minimal() +
      theme(
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_line(colour = "azure2"),
        panel.grid.minor.y = element_line(colour = "azure2"),
        panel.grid.major.x = element_blank(),
        plot.title = element_text(face = "bold", size = 13),
        plot.subtitle = element_text(face = "italic"),
        axis.title = element_text(face = "bold", size = 13),
        axis.text.x = element_text(angle = 40))  
    
  })
  
  #Birth rate graph
  dataInput3 <- reactive({
    switch(input$choose,  
           "Drenthe" = Births %>% filter(Region == "Drenthe"),
           "Groningen" = Births %>% filter(Region == "Groningen"),
           "Fryslân" = Births %>% filter(Region == "Fryslân"))
  })
  
  output$Birthrate <- renderPlot({
    ggplot(dataInput3(), aes(x = Period, y = percentageZ)) + 
      geom_bar(stat = "summary", fun = "mean", fill = "blue") +
      scale_y_continuous(
        breaks = seq(0, 1.3, 0.1),
        limits = c(0, 1.3)
      ) +
      geom_text(aes(label=Total, x=Period, y=0.9*percentageZ), colour="aliceblue") +
      labs(
        title = "Number of births per year",
        subtitle = "Data about Groningen, Drenthe and Fryslând(Statline)",
        x = "Year periods",
        y = "Birth ratio ((count / population) x 100)"
      ) +
      theme_minimal() +
      theme(
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_line(colour = "azure2"),
        panel.grid.minor.y = element_line(colour = "azure2"),
        panel.grid.major.x = element_blank(),
        plot.title = element_text(face = "bold", size = 13),
        plot.subtitle = element_text(face = "italic"),
        axis.title = element_text(face = "bold", size = 13),
        axis.text.x = element_text(angle = 40))  
    
  })
  
  #Plot Businesses Distribution
  NothernNLBusinessesReactive <- reactive({NothernNLBusinesses %>% filter(Period == input$BussSlider)})
  
  GroningenBusinessesReactive <- reactive({GroningenBusinesses %>% filter(Period == input$BussSlider)})
  
  FryslandBusinessesReactive <- reactive({FryslandBusinesses %>% filter(Period == input$BussSlider)})
  
  DrentheBusinessesReactive <- reactive({DrentheBusinesses %>% filter(Period == input$BussSlider)})
  
  output$BusinessPlotNL <- renderPlot(
    ggplot(data = NothernNLBusinessesReactive(), aes(x = "", y = Percentage, fill = Industry_Sector))+
      geom_bar(stat = "identity", color = "black")+ 
      coord_polar("y", start = 0)+
      theme_bw()+ 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.background = element_rect(fill = "aliceblue")) +
      labs(
        title = "Businesses in the Nothern Netherlands"))
  
  
  output$BusinessPlotGroningen <- renderPlot(
    ggplot(data = GroningenBusinessesReactive(), aes(x = "", y = Percentage, fill = Industry_Sector))+
      geom_bar(stat = "identity", color = "black")+ 
      coord_polar("y", start = 0)+
      theme_bw()+ 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.background = element_rect(fill = "aliceblue")) +
      labs(
        title = "Businesses in the Groningen Province"))
  
  output$BusinessPlotFrysland <- renderPlot(
    ggplot(data = FryslandBusinessesReactive(), aes(x = "", y = Percentage, fill = Industry_Sector))+
      geom_bar(stat = "identity", color = "black")+ 
      coord_polar("y", start = 0)+
      theme_bw()+ 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.background = element_rect(fill = "aliceblue")) +
      labs(
        title = "Businesses in the Frysland Province"))
  
  output$BusinessPlotDrenthe <- renderPlot(
    ggplot(data = DrentheBusinessesReactive(), aes(x = "", y = Percentage, fill = Industry_Sector))+
      geom_bar(stat = "identity", color = "black")+ 
      coord_polar("y", start = 0)+
      theme_bw()+ 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.background = element_rect(fill = "aliceblue")) +
      labs(
        title = "Businesses in the Drenthe Province"))
  
  output$BusinessPlotLine <- renderPlotly(
    ggplot(data = NothernNLBusinesses, aes(x = Period, y = Total_Businesses, group = 1)) +
      geom_line(data = GroningenBusinesses, aes(x = Period, y = Total_Businesses, alpha = "Groningen", colour = "#FF0000", group = 1)) +
      geom_line(data = FryslandBusinesses, aes(x = Period, y = Total_Businesses, alpha = "Fryslând", colour = "#0000FF", group = 1)) +
      geom_line(data = DrentheBusinesses, aes(x = Period, y = Total_Businesses, alpha = "Drenthe", colour = "#52E74B", group = 1)) + 
      theme_bw() + 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.subtitle = element_text(size = 13, family = "Times",
                                     face = "italic"),
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_line(colour = "azure1"),
        panel.grid.minor.y = element_line(colour = "azure2"),
        panel.grid.major.x = element_blank(),
        axis.title = element_text(size = 12, face = "bold"),
        axis.text.x = element_text(angle = 40),
        legend.text = element_text(size = 12),
        legend.title = element_text(size = 14)
      ) +
      labs(
        x = "Years", y = "# of Businesses",
        title = "Number of Businesses per Province",
        subtitle = "Groningen, Fryslând, Drenthe",
        text = "Frysland", "Groningen", "Drenthe"
      )
  )
  
  #PLOT BENEFIT RECIPIENTS
  output$plotBenefitR <- renderPlotly(
    ggplot(data = Benefit_recipients, aes(x = Period, y = Total, color = Region, group = 1)) +
      geom_line(data = Drenthe1, aes(x = Period, y = Total, group = 1)) +
      geom_line(data = Groningen1, aes(x = Period, y = Total, group = 1)) +
      geom_line(data = Fryslan1, aes(x = Period, y = Total, group = 1)) + 
      theme_bw() + 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.subtitle = element_text(size = 13, family = "Times",
                                     face = "italic"),
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_line(colour = "azure2"),
        panel.grid.minor.y = element_line(colour = "azure2"),
        panel.grid.major.x = element_blank(),
        axis.title = element_text(size = 12, face = "bold"),
        axis.text.x = element_text(angle = 40)
      ) +
      labs(
        x = "Years", y = "Benefit recipients",
        title = "Number of benefit recipients per province",
        subtitle = "Groningen, Fryslând, Drenthe",
        color = "Region" )
  )
  
  #PLOT UNEMPLOYMENT
  output$plotUnemployment <- renderPlotly(
    ggplot(data = Unemployment, aes(x = Period, y = Total, color = Region, group = 1)) +
      geom_line(data = Drenthe2, aes(x = Period, y = Total, group = 1)) +
      geom_line(data = Groningen2, aes(x = Period, y = Total, group = 1)) +
      geom_line(data = Fryslan2, aes(x = Period, y = Total, group = 1)) + 
      theme_bw() + 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.subtitle = element_text(size = 13, family = "Times",
                                     face = "italic"),
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_line(colour = "azure2"),
        panel.grid.minor.y = element_line(colour = "azure2"),
        panel.grid.major.x = element_blank(),
        axis.title = element_text(size = 12, face = "bold"),
        axis.text.x = element_text(angle = 40)
      ) +
      labs(
        x = "Years", y = "Unemployed persons",
        title = "Number of unemployed persons per province",
        subtitle = "Groningen, Fryslând, Drenthe",
        color = "Region" )
  )
  
  #GDP Graph
  output$plotBBP <- renderPlotly(
    ggplot(data = BBP, aes(x = Period, y = Total, color = Region, group = 1)) +
      geom_line(data = NederlandBBP, aes(x = Period, y = Total, group = 1), linetype = "dashed") +
      geom_line(data = DrenghteBBP, aes(x = Period, y = Total, group = 1)) +
      geom_line(data = GroningenBBP, aes(x = Period, y = Total, group = 1)) +
      geom_line(data = FryslândBBP, aes(x = Period, y = Total, group = 1)) +
      scale_y_continuous(
        breaks = seq(10000, 55000, 5000),
        limits = c(10000, 55000),
        labels = c(
          "10000" = "€10000",
          "15000" = "€15000",
          "20000" = "€20000",
          "25000" = "€25000",
          "30000" = "€30000",
          "35000" = "€35000",
          "40000" = "€40000",
          "45000" = "€45000",
          "50000" = "€50000",
          "55000" = "€55000")
      ) +
      theme_bw() + 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.subtitle = element_text(size = 13, family = "Times",
                                     face = "italic"),
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_line(colour = "azure2"),
        panel.grid.minor.y = element_line(colour = "azure2"),
        panel.grid.major.x = element_blank(),
        axis.title = element_text(size = 12, face = "bold"),
        axis.text.x = element_text(angle = 40)
      ) +
      labs(
        x = "Years", y = "GDP per citizen",
        title = "Gross domestic product with respect to Dutch average",
        subtitle = "Groningen, Fryslând, Drenthe",
        color = "Region"
      )
  )
  
  #EMPLOYMENT PLOT
  output$plot10 <- renderPlotly(ggplot(data = employment, aes(x = Period, y = Total, color = Region), group = 1) +
                                  geom_line(data = groningen_emp, aes(x = Period, y = Total, group = 1)) +
                                  geom_line(data = drenthe_emp, aes(x = Period, y = Total, group = 1)) +
                                  geom_line(data = friesland_emp, aes(x = Period, y = Total, group = 1)) +
                                  theme_bw() + 
                                  theme(
                                    plot.title = element_text(size = 15, family = "Times", face = "bold"),
                                    plot.subtitle = element_text(size = 13, family = "Times",
                                                                 face = "italic"),
                                    plot.background = element_rect(fill = "aliceblue"),
                                    panel.grid.major.y = element_line(colour = "azure2"),
                                    panel.grid.minor.y = element_line(colour = "azure2"),
                                    panel.grid.major.x = element_blank(),
                                    axis.title = element_text(size = 12, face = "bold"),
                                    axis.text.x = element_text(angle = 40)
                                  ) +
                                  labs(
                                    x = "Years", y = "Number of employed persons (x1000)",
                                    title = "Labor force of the northern Netherlands",
                                    color = "Region"
                                  )
  )
  #primary income plot
  output$primaryincome <- renderPlotly(ggplot(data = incomes, aes(x = Period, y = Total, color = Region), group = 1) +
                                         geom_line(data = groningenincomes, aes(x = Period, y = Total, group = 1)) +
                                         geom_line(data = drentheincomes, aes(x = Period, y = Total, group = 1)) +
                                         geom_line(data = frieslandincomes, aes(x = Period, y = Total, group = 1)) +
                                         theme_bw() + 
                                         theme(
                                           plot.title = element_text(size = 15, family = "Times", face = "bold"),
                                           plot.subtitle = element_text(size = 13, family = "Times",
                                                                        face = "italic"),
                                           plot.background = element_rect(fill = "aliceblue"),
                                           panel.grid.major.y = element_line(colour = "azure2"),
                                           panel.grid.minor.y = element_line(colour = "azure2"),
                                           panel.grid.major.x = element_blank(),
                                           axis.title = element_text(size = 12, face = "bold"),
                                           axis.text.x = element_text(angle = 40)
                                         ) +
                                         labs(
                                           x = "Years", y = "Income in EUR",
                                           title = "Net Primary Income per Capita",
                                           color = "Region"
                                         )
  )
  
  #PLOT BELONING VAN WERKNEMERS
  output$plotBvw <- renderPlotly(
    ggplot(data = Belonging_van_werknemers, aes(x = Period, y = Total, color = Region), group = 1) +
      geom_line(data = nl_bvw, aes(x = Period, y = Total, group = 1),linetype = "dashed") +
      geom_line(data = groningen_bvw, aes(x = Period, y = Total, group = 1)) +
      geom_line(data = drenthe_bvw, aes(x = Period, y = Total, group = 1)) +
      geom_line(data = friesland_bvw, aes(x = Period, y = Total, group = 1)) +
      theme_bw() + 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.subtitle = element_text(size = 13, family = "Times",
                                     face = "italic"),
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_line(colour = "azure2"),
        panel.grid.minor.y = element_line(colour = "azure2"),
        panel.grid.major.x = element_blank(),
        axis.title = element_text(size = 11, face = "bold"),
        axis.text.x = element_text(angle = 40)
      ) +
      labs(
        x = "Years", y = "Compensation per employee(x 1000 euros)",
        title = "Compensation per employee of the northern Netherlands",
        color = "Region")
  )
  
  # PLOT BUSINESS CONFIDENCE 
  output$plotBusinessConfidence <- renderPlotly(
    ggplot(data = Business_confidence, aes(x = Period, y = Confidence, color = Region, group = 1)) +
      geom_line(data = DrentheBC, aes(x = Period, y = Confidence, group = 1)) +
      geom_line(data = GroningenBC, aes(x = Period, y = Confidence, group = 1)) +
      geom_line(data = FryslanBC, aes(x = Period, y = Confidence, group = 1)) + 
      theme_bw() + 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.subtitle = element_text(size = 13, family = "Times",
                                     face = "italic"),
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_line(colour = "azure2"),
        panel.grid.minor.y = element_line(colour = "azure2"),
        panel.grid.major.x = element_blank(),
        axis.title = element_text(size = 12, face = "bold"),
        axis.text.x = element_text(angle = 40)
      ) +
      labs(
        x = "Quarters", y = "Business confidence",
        title = "The average level of business confidence / quarter ",
        subtitle = "Groningen, Fryslând, Drenthe",
        color = "Region") +
      scale_x_discrete(
        breaks = c("2014KW01", 
                   "2015KW01",
                   "2016KW01",
                   "2017KW01",
                   "2018KW01",
                   "2019KW01",
                   "2020KW01",
                   "2021KW01" ),
        labels = c("2014", 
                   "2015",
                   "2016",
                   "2017",
                   "2018",
                   "2019",
                   "2020",
                   "2021"))
  )
  
  
  #plot gross added values
  output$grossvalue <- renderPlotly(
    ggplot(data = values, aes(x = Period, y = Total, color = Region), group = 1) +
      geom_line(data = groningengad, aes(x = Period, y = Total, group = 1)) +
      geom_line(data = drenthegad, aes(x = Period, y = Total, group = 1)) +
      geom_line(data = frieslandgad, aes(x = Period, y = Total, group = 1)) +
      theme_bw() + 
      theme(
        plot.title = element_text(size = 15, family = "Times", face = "bold"),
        plot.subtitle = element_text(size = 13, family = "Times",
                                     face = "italic"),
        plot.background = element_rect(fill = "aliceblue"),
        panel.grid.major.y = element_line(colour = "azure2"),
        panel.grid.minor.y = element_line(colour = "azure2"),
        panel.grid.major.x = element_blank(),
        axis.title = element_text(size = 12, face = "bold"),
        axis.text.x = element_text(angle = 40)
      ) +
      labs(
        x = "Years", y = "Gross added value as percentage",
        title = "Gross added value, volume changes in percentages",
        color = "Region"
      )
  )
  
  #Plot socialism
  output$psocials <- renderPlotly(ggplot(data = socials, aes(x = Period, y = Total, color = Region), group = 1) +
                                    geom_line(data = groningensocial, aes(x = Period, y = Total, group = 1)) +
                                    geom_line(data = drenthesocial, aes(x = Period, y = Total, group = 1)) +
                                    geom_line(data = frieslandsocial, aes(x = Period, y = Total, group = 1)) +
                                    theme_bw() + 
                                    theme(
                                      plot.title = element_text(size = 15, family = "Times", face = "bold"),
                                      plot.subtitle = element_text(size = 13, family = "Times",
                                                                   face = "italic"),
                                      plot.background = element_rect(fill = "aliceblue"),
                                      panel.grid.major.y = element_line(colour = "azure2"),
                                      panel.grid.minor.y = element_line(colour = "azure2"),
                                      panel.grid.major.x = element_blank(),
                                      axis.title = element_text(size = 12, face = "bold"),
                                      axis.text.x = element_text(angle = 40)
                                    ) +
                                    labs(
                                      x = "Years", y = "Social assistance in EUR (thousands)",
                                      title = "Total social assistance (up to pension age)",
                                      color = "Region"
                                    )
  )
  
  #create the map for eathquake graph
  output$mymap <- renderLeaflet({
    leaflet(data= Groningen_municipality) %>% 
      setView(lng = 5.7, lat = 53, zoom = 8) %>%
      addTiles() %>%
      addPolygons(data = Groningen_municipality, stroke = FALSE, color = "green", weight = 6) %>%
      addPolygons(data = Drenthe_municipality, stroke = FALSE, color = "green", weight = 6) %>%
      addPolygons(data = Frysland_municipality, stroke = FALSE, color = "green",  weight = 6) %>%
      addCircles(data = df(), lat = ~ LAT, lng = ~ LON, weight = 1, radius = ~MAG*250,
                 popup = ~as.character(MAG), label = ~as.character(paste0("Magnitude: ", sep = " ", MAG, "\nLocation: ", sep = " ", LOCATION)), color = ~pal(MAG), fillOpacity = 0.3)
  })
  
  df <- reactive({
    
    # First, I make a new variable that gives the value of the slider in the same format as the YYMMDD format.
    # Then I filter the data based on that new variable
    dat <- data %>%
      mutate(slider = paste0(substr(as.character(input$date),1,4),substr(as.character(input$date),6,7),substr(as.character(input$date),9,10))) %>%
      filter(YYMMDD <= slider)
    
    dat
  })
  
  observe({
    proxy <- leafletProxy("mymap", data = df()) # Rosanne: here you call the data. As the data is in a function, use () behind the name of the function.I don't know exactly what this part does, so check whether you want to load data (all data) or d f (part of the data based on slider)
    # browser() Rosanne: the browser function stops your code as this point. Then you can see how the proxy element (in which your data is) looks like at this moment. Is this how you want it? No, then you know something is not going good.
    proxy %>% clearMarkers()
    if (input$markers) {
      proxy %>% addCircleMarkers(stroke = FALSE, color = ~pal2(depth_type), fillOpacity = 0.1, label = ~as.character(paste0("Magnitude: ", sep = " ", MAG,    "\nLocation: ", sep = " ", LOCATION))) %>%
        addLegend("bottomright", pal = pal2, values = df()$depth_type, # Rosanne: same here
                  title = "Depth Type",
                  opacity = 1)}
    else {
      proxy %>% clearMarkers() %>% clearControls()
    }
  })
  
  observe({
    proxy <- leafletProxy("mymap", data = df())
    proxy %>% clearMarkers()
    if (input$heat) {
      proxy %>%  addHeatmap(lng=~LON, lat=~LAT, intensity =~MAG, blur =  10, max = 0.05, radius = 15) 
    }
    else{
      proxy %>% clearHeatmap()
    }
  })
  
#educational graph
  output$ploteduVO <- renderPlotly(ggplot(data = edulevels, aes(x = Period, y = VO, color = Region, group = 1))+
                                     geom_line(data = Groningenedulevels, aes(x = Period, y = VO, group = 1)) +
                                     geom_line(data = Fryslanedulevels, aes(x = Period, y = VO, group = 1)) +
                                     geom_line(data = Drentheedulevels, aes(x = Period, y = VO, group = 1)) +
                                     theme_bw() + 
                                     theme(
                                       plot.title = element_text(size = 15, family = "Times", face = "bold"),
                                       plot.subtitle = element_text(size = 13, family = "Times", face = "italic"),
                                       plot.background = element_rect(fill = "aliceblue"),
                                       panel.grid.major.y = element_line(colour = "azure2"),
                                       panel.grid.minor.y = element_line(colour = "azure2"),
                                       panel.grid.major.x = element_blank(),
                                       axis.title = element_text(size = 12, face = "bold"),
                                       axis.text.x = element_text(angle = 40)) +
                                     labs(
                                       x = "Year", y = "Number of Graduates",
                                       title = "VO Graduates in the Provinces",
                                       color = "Region"))
  
  output$ploteduMBO <- renderPlotly(ggplot(data = edulevels, aes(x = Period, y = MBO, color = Region, group = 1))+
                                      geom_line(data = Groningenedulevels, aes(x = Period, y = MBO, group = 1)) +
                                      geom_line(data = Fryslanedulevels, aes(x = Period, y = MBO, group = 1)) +
                                      geom_line(data = Drentheedulevels, aes(x = Period, y = MBO, group = 1)) +
                                      theme_bw() + 
                                      theme(
                                        plot.title = element_text(size = 15, family = "Times", face = "bold"),
                                        plot.subtitle = element_text(size = 13, family = "Times", face = "italic"),
                                        plot.background = element_rect(fill = "aliceblue"),
                                        panel.grid.major.y = element_line(colour = "azure2"),
                                        panel.grid.minor.y = element_line(colour = "azure2"),
                                        panel.grid.major.x = element_blank(),
                                        axis.title = element_text(size = 12, face = "bold"),
                                        axis.text.x = element_text(angle = 40)) +
                                      labs(
                                        x = "Year", y = "Number of Graduates",
                                        title = "MBO Graduates in the Provinces",
                                        color = "Region"))
  
  output$ploteduHBO <- renderPlotly(ggplot(data = edulevels, aes(x = Period, y = HBO, color = Region, group = 1))+
                                      geom_line(data = Groningenedulevels, aes(x = Period, y = HBO, group = 1)) +
                                      geom_line(data = Fryslanedulevels, aes(x = Period, y = HBO, group = 1)) +
                                      geom_line(data = Drentheedulevels, aes(x = Period, y = HBO, group = 1)) +
                                      theme_bw() + 
                                      theme(
                                        plot.title = element_text(size = 15, family = "Times", face = "bold"),
                                        plot.subtitle = element_text(size = 13, family = "Times", face = "italic"),
                                        plot.background = element_rect(fill = "aliceblue"),
                                        panel.grid.major.y = element_line(colour = "azure2"),
                                        panel.grid.minor.y = element_line(colour = "azure2"),
                                        panel.grid.major.x = element_blank(),
                                        axis.title = element_text(size = 12, face = "bold"),
                                        axis.text.x = element_text(angle = 40)) +
                                      labs(
                                        x = "Year", y = "Number of Graduates",
                                        title = "HBO Graduates in the Provinces",
                                        color = "Region"))
  
  output$ploteduWO <- renderPlotly(ggplot(data = edulevels, aes(x = Period, y = WO, color = Region, group = 1))+
                                     geom_line(data = Groningenedulevels, aes(x = Period, y = WO, group = 1)) +
                                     geom_line(data = Fryslanedulevels, aes(x = Period, y = WO, group = 1)) +
                                     geom_line(data = Drentheedulevels, aes(x = Period, y = WO, group = 1)) +
                                     theme_bw() + 
                                     theme(
                                       plot.title = element_text(size = 15, family = "Times", face = "bold"),
                                       plot.subtitle = element_text(size = 13, family = "Times", face = "italic"),
                                       plot.background = element_rect(fill = "aliceblue"),
                                       panel.grid.major.y = element_line(colour = "azure2"),
                                       panel.grid.minor.y = element_line(colour = "azure2"),
                                       panel.grid.major.x = element_blank(),
                                       axis.title = element_text(size = 12, face = "bold"),
                                       axis.text.x = element_text(angle = 40)) +
                                     labs(
                                       x = "Year", y = "Number of Graduates",
                                       title = "WO Graduates in the Provinces",
                                       color = "Region"))
  ## download button for demographics
  output$download_demographics <- downloadHandler(
    filename = function() {
      paste("demographics", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(demographics, file) } )
  
  ## download button for economics 
  output$download_economics <- downloadHandler(
    filename = function() {
      paste("economics", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(economic_indicators, file) } )
  
  ## download button for business confidence 
  output$download_business_confidence <- downloadHandler(
    filename = function() {
      paste("Business_confidence", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(Business_confidence, file) } )
  
  ## download button for regional key figures 
  output$download_regionalfigures <- downloadHandler(
    filename = function() {
      paste("Regional_keyfigures", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(regionalkeyfigures, file) } )
  
  ## download button for earthquakes 
  output$download_earthquake <- downloadHandler(
    filename = function() {
      paste("Earthquake", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(data, file) } )
  
}

#CODE TO RUN THE APP
shinyApp(ui = ui, server = server)
